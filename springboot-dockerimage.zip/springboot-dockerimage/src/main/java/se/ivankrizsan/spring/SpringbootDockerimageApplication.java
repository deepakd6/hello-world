package se.ivankrizsan.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDockerimageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDockerimageApplication.class, args);
	}
}
